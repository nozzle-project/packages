#!/bin/bash

set -e

echo "🚀 Instalando Nozzle..."

BIN="./nozzle"
DEST="/usr/local/bin/nozzle"

if [ ! -f "$BIN" ]; then
    echo "❌ Binário 'nozzle' não encontrado no diretório atual."
    exit 1
fi

# Copia com permissão
sudo install -m 0755 "$BIN" "$DEST"

echo "✅ Nozzle instalado em $DEST"
$DEST --version || true
